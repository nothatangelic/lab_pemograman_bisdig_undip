(function(){
  "use strict";

  /* =========================================================
     KONFIGURASI
     - Ganti PIN ini sebelum deploy ke Netlify (dicek di browser,
       jadi cukup untuk demo tugas akhir, BUKAN keamanan produksi).
     ========================================================= */
  var ADMIN_PIN = "beasiswa2026";

  var LS_PROFILE = "bm_profile";
  var LS_SAVED = "bm_saved";
  var LS_OVERRIDES = "bm_overrides";
  var LS_DELETED = "bm_deleted";
  var LS_IS_ADMIN = "bm_is_admin";
  var LS_VISITS = "bm_visits_local";

  /* ===================== utils ===================== */
  function esc(s){
    return String(s === undefined || s === null ? "" : s)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
  }
  function escapeAttr(s){ return esc(s); }
  function toast(msg){
    var wrap = document.getElementById("toastWrap");
    var t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    wrap.appendChild(t);
    setTimeout(function(){ t.remove(); }, 3200);
  }
  function fmtDate(iso){
    if(!iso) return "-";
    var d = new Date(iso + "T00:00:00");
    if(isNaN(d.getTime())) return iso;
    return d.toLocaleDateString("id-ID", {day:"numeric",month:"short",year:"numeric"});
  }
  function daysLeft(iso){
    if(!iso) return null;
    var d = new Date(iso + "T00:00:00");
    if(isNaN(d.getTime())) return null;
    var today = new Date(); today.setHours(0,0,0,0);
    return Math.round((d - today) / 86400000);
  }
  function ticketDeadline(iso){
    var dl = daysLeft(iso);
    if(dl === null) return '<span class="ticket">Tanpa tenggat</span>';
    if(dl < 0) return '<span class="ticket">Tenggat lewat</span>';
    if(dl === 0) return '<span class="ticket ticket-urgent">Tenggat hari ini</span>';
    if(dl <= 7) return '<span class="ticket ticket-urgent">'+dl+' hari lagi</span>';
    if(dl <= 21) return '<span class="ticket ticket-warn">'+dl+' hari lagi</span>';
    return '<span class="ticket ticket-ok">'+dl+' hari lagi</span>';
  }
  function listify(str){
    if(!str) return [];
    return str.split(",").map(function(s){return s.trim();}).filter(Boolean);
  }
  function uid8(){ return "u" + Date.now().toString(36) + Math.random().toString(36).slice(2,8); }
  function readLS(key, fallback){
    try{ var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }catch(e){ return fallback; }
  }
  function writeLS(key, val){
    try{ localStorage.setItem(key, JSON.stringify(val)); }catch(e){ toast("Penyimpanan lokal browser penuh/diblokir."); }
  }
  function animateCount(el){
    var target = parseInt(el.dataset.countto, 10);
    if(isNaN(target)) return;
    var reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if(reduced){ el.textContent = target; return; }
    var start = null, dur = 650;
    function step(ts){
      if(!start) start = ts;
      var p = Math.min(1, (ts - start) / dur);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(eased * target);
      if(p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  function animateAllCounts(){ document.querySelectorAll('[data-countto]').forEach(animateCount); }

  var PROVINSI = ["DKI Jakarta","Jawa Barat","Jawa Tengah","DI Yogyakarta","Jawa Timur","Banten","Bali",
    "Sumatera Utara","Sumatera Barat","Sumatera Selatan","Riau","Lampung","Aceh","Kalimantan Timur",
    "Kalimantan Barat","Kalimantan Selatan","Sulawesi Selatan","Sulawesi Utara","Nusa Tenggara Barat",
    "Nusa Tenggara Timur","Papua","Maluku","Jambi","Bengkulu","Kepulauan Riau","Bangka Belitung","Semua"];

  /* ===================== state ===================== */
  var state = {
    view: "beranda",
    isAdmin: readLS(LS_IS_ADMIN, false),
    profile: readLS(LS_PROFILE, null),
    saved: readLS(LS_SAVED, {}),
    adminTab: "aktif",
    filters: { q:"", jenjang:"", jenis:"", onlyMatch:false }
  };

  /* ===================== data layer (localStorage, no server) ===================== */
  function getScholarships(){
    var overrides = readLS(LS_OVERRIDES, {});
    var deleted = readLS(LS_DELETED, []);
    var map = {};
    DEFAULT_SCHOLARSHIPS.forEach(function(s){ map[s.id] = Object.assign({}, s); });
    Object.keys(overrides).forEach(function(id){ map[id] = Object.assign({}, map[id] || {id:id}, overrides[id]); });
    deleted.forEach(function(id){ delete map[id]; });
    return Object.keys(map).map(function(k){ return map[k]; });
  }
  function allScholarships(){ return getScholarships(); }
  function activeScholarships(){ return allScholarships().filter(function(s){ return s.statusAktif !== false; }); }
  function findScholarship(id){ return getScholarships().filter(function(s){ return s.id === id; })[0] || null; }

  /* ===================== matching logic ===================== */
  function matchResult(sch, profile){
    var req = sch.syarat || {};
    var reasons = [];
    if(!profile) return {ok:false, reasons:["Lengkapi profil untuk melihat kecocokan"]};

    var jenjangList = req.jenjang && req.jenjang.length ? req.jenjang : ["Semua"];
    var jenjangOk = jenjangList.indexOf("Semua") !== -1 || jenjangList.indexOf(profile.jenjang) !== -1;
    if(!jenjangOk) reasons.push("Jenjang " + (profile.jenjang||"-") + " tidak termasuk");

    var jurusanList = req.jurusanList && req.jurusanList.length ? req.jurusanList : ["Semua"];
    var pj = (profile.jurusan||"").toLowerCase();
    var jurusanOk = jurusanList.indexOf("Semua") !== -1 || jurusanList.some(function(j){
      var jl = j.toLowerCase();
      return pj.indexOf(jl) !== -1 || jl.indexOf(pj) !== -1;
    });
    if(!jurusanOk) reasons.push("Jurusan tidak sesuai kriteria");

    var ipkMin = typeof req.ipkMin === "number" ? req.ipkMin : 0;
    var ipkOk = (typeof profile.ipk === "number" ? profile.ipk : 0) >= ipkMin;
    if(!ipkOk) reasons.push("IPK minimum " + ipkMin.toFixed(2));

    var domList = req.domisili && req.domisili.length ? req.domisili : ["Semua"];
    var domisiliOk = domList.indexOf("Semua") !== -1 || domList.indexOf(profile.domisili) !== -1;
    if(!domisiliOk) reasons.push("Domisili di luar cakupan");

    return {ok: jenjangOk && jurusanOk && ipkOk && domisiliOk, reasons: reasons};
  }

  /* ===================== actions ===================== */
  function saveProfile(data){
    state.profile = data;
    writeLS(LS_PROFILE, data);
    toast("Profil tersimpan di browser ini.");
    render();
  }
  function saveScholarship(id){
    state.saved[id] = { statusPersiapan:"Belum mulai", berkas:[], catatan:"", savedAt:new Date().toISOString() };
    writeLS(LS_SAVED, state.saved);
    toast("Beasiswa disimpan ke daftar Anda.");
    render();
  }
  function unsaveScholarship(id){
    delete state.saved[id];
    writeLS(LS_SAVED, state.saved);
    toast("Dihapus dari daftar tersimpan.");
    render();
  }
  function updateSavedStatus(id, status){
    if(!state.saved[id]) return;
    state.saved[id].statusPersiapan = status;
    writeLS(LS_SAVED, state.saved);
  }
  function addBerkasItem(id, nama){
    if(!state.saved[id] || !nama.trim()) return;
    state.saved[id].berkas = (state.saved[id].berkas||[]).concat([{nama:nama.trim(), selesai:false}]);
    writeLS(LS_SAVED, state.saved);
    render();
  }
  function toggleBerkasItem(id, idx){
    if(!state.saved[id]) return;
    var arr = state.saved[id].berkas || [];
    arr[idx].selesai = !arr[idx].selesai;
    writeLS(LS_SAVED, state.saved);
    render();
  }
  function removeBerkasItem(id, idx){
    if(!state.saved[id]) return;
    state.saved[id].berkas = (state.saved[id].berkas||[]).filter(function(_,i){return i!==idx;});
    writeLS(LS_SAVED, state.saved);
    render();
  }

  function adminUpsertScholarship(data, existingId){
    var overrides = readLS(LS_OVERRIDES, {});
    var id = existingId || uid8();
    data.tanggalPembaruan = new Date().toISOString().slice(0,10);
    if(typeof data.statusAktif !== "boolean") data.statusAktif = true;
    overrides[id] = Object.assign({}, overrides[id]||{}, data, {id:id});
    writeLS(LS_OVERRIDES, overrides);
    toast(existingId ? "Beasiswa diperbarui." : "Beasiswa baru ditambahkan.");
    closeModal();
    render();
  }
  function adminSetActive(id, active){
    var overrides = readLS(LS_OVERRIDES, {});
    overrides[id] = Object.assign({}, overrides[id]||{}, {statusAktif:active, tanggalPembaruan:new Date().toISOString().slice(0,10)});
    writeLS(LS_OVERRIDES, overrides);
    toast(active ? "Diaktifkan kembali." : "Beasiswa dinonaktifkan.");
    render();
  }
  function adminDelete(id){
    if(!confirm("Hapus data beasiswa ini dari situs?")) return;
    var deleted = readLS(LS_DELETED, []);
    if(deleted.indexOf(id) === -1) deleted.push(id);
    writeLS(LS_DELETED, deleted);
    var overrides = readLS(LS_OVERRIDES, {});
    delete overrides[id];
    writeLS(LS_OVERRIDES, overrides);
    toast("Data beasiswa dihapus.");
    render();
  }
  function adminResetData(){
    if(!confirm("Kembalikan semua data beasiswa ke contoh bawaan? Perubahan admin akan hilang.")) return;
    localStorage.removeItem(LS_OVERRIDES);
    localStorage.removeItem(LS_DELETED);
    toast("Data beasiswa direset ke contoh bawaan.");
    render();
  }

  function tryAdminLogin(){
    var pin = prompt("Masukkan PIN admin untuk mengelola data beasiswa:");
    if(pin === null) return;
    if(pin === ADMIN_PIN){
      state.isAdmin = true;
      writeLS(LS_IS_ADMIN, true);
      document.getElementById("navAdmin").classList.remove("hidden");
      updateStatusPill();
      toast("Masuk sebagai Admin.");
      navigate("admin");
    } else {
      toast("PIN salah.");
    }
  }
  function adminLogout(){
    state.isAdmin = false;
    writeLS(LS_IS_ADMIN, false);
    document.getElementById("navAdmin").classList.add("hidden");
    updateStatusPill();
    navigate("beranda");
    toast("Keluar dari mode admin.");
  }

  function updateStatusPill(){
    var pill = document.getElementById("statusPill");
    pill.textContent = state.isAdmin ? "Admin" : "Pengunjung";
    pill.className = "pill clickable";
    pill.onclick = state.isAdmin ? adminLogout : tryAdminLogin;
    pill.title = state.isAdmin ? "Klik untuk keluar dari mode admin" : "Klik untuk masuk sebagai admin";
  }

  function trackLocalVisit(){
    try{
      if(!sessionStorage.getItem("bm_counted")){
        var n = readLS(LS_VISITS, 0) + 1;
        writeLS(LS_VISITS, n);
        sessionStorage.setItem("bm_counted", "1");
      }
    }catch(e){}
  }

  /* ===================== router / render ===================== */
  function navigate(view){
    state.view = view;
    document.getElementById("mainNav").classList.remove("open");
    window.scrollTo({top:0,behavior:"smooth"});
    render();
  }

  function render(){
    var main = document.getElementById("mainContent");
    document.querySelectorAll("nav.main-nav button").forEach(function(b){
      b.classList.toggle("active", b.dataset.view === state.view);
    });
    if(state.view === "admin" && !state.isAdmin){ state.view = "beranda"; }
    switch(state.view){
      case "cari": main.innerHTML = viewCari(); afterRenderCari(); break;
      case "tersimpan": main.innerHTML = viewTersimpan(); afterRenderTersimpan(); break;
      case "profil": main.innerHTML = viewProfil(); afterRenderProfil(); break;
      case "admin": main.innerHTML = viewAdmin(); afterRenderAdmin(); break;
      default: main.innerHTML = viewBeranda(); afterRenderBeranda();
    }
  }

  function ledgerItem(num, lbl){
    return '<div class="ledger-item"><div class="num" data-countto="'+num+'">0</div><div class="lbl">'+lbl+'</div></div>';
  }

  /* ---------- BERANDA ---------- */
  function viewBeranda(){
    var active = activeScholarships();
    var withDeadline = active.filter(function(s){ return s.tenggat; });
    var urgent = withDeadline.filter(function(s){ var d = daysLeft(s.tenggat); return d !== null && d >= 0 && d <= 14; }).length;
    var savedCount = Object.keys(state.saved).length;
    var matchedCount = state.profile ? active.filter(function(s){ return matchResult(s, state.profile).ok; }).length : 0;

    var html = '';
    html += '<section class="hero">';
    html += '<h1>Temukan beasiswa yang benar-benar sesuai dengan profil Anda</h1>';
    html += '<p>BeasiswaMatch menghimpun informasi beasiswa dari kampus, pemerintah, BUMN, hingga yayasan swasta — lalu mencocokkannya otomatis dengan jenjang, jurusan, IPK, dan domisili Anda, lengkap dengan pengingat tenggat pendaftaran.</p>';
    html += '<div class="hero-actions">';
    html += '<button class="btn btn-primary" data-nav="profil">'+(state.profile ? "Perbarui profil" : "Lengkapi profil saya")+'</button>';
    html += '<button class="btn btn-outline" data-nav="cari">Jelajahi beasiswa</button>';
    html += '</div></section>';

    html += '<div class="ledger">';
    html += ledgerItem(active.length, "Beasiswa aktif terdaftar");
    html += ledgerItem(urgent, "Tenggat ≤ 14 hari ke depan");
    html += state.profile ? ledgerItem(matchedCount, "Cocok dengan profil Anda") : '<div class="ledger-item"><div class="num">—</div><div class="lbl">Cocok dengan profil Anda</div></div>';
    html += ledgerItem(savedCount, "Beasiswa Anda simpan");
    html += '</div>';

    html += '<div class="grid-2col">';

    html += '<div class="card" style="padding:22px;">';
    html += '<h3 style="margin:0 0 4px;font-size:16px;font-weight:800;">Beasiswa dengan tenggat terdekat</h3>';
    html += '<p class="section-sub" style="margin-bottom:14px;">Pantau sebelum kesempatan terlewat.</p>';
    var soon = withDeadline.slice().sort(function(a,b){ return daysLeft(a.tenggat) - daysLeft(b.tenggat); }).slice(0,5);
    if(soon.length){
      html += '<div class="sch-list">';
      soon.forEach(function(s){
        html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--line);gap:10px;">';
        html += '<div style="min-width:0;"><div style="font-weight:700;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+esc(s.nama)+'</div>';
        html += '<div style="font-size:12px;color:var(--ink-faint);">'+esc(s.penyelenggara||"")+'</div></div>';
        html += ticketDeadline(s.tenggat);
        html += '</div>';
      });
      html += '</div>';
    } else {
      html += '<div class="empty"><div class="big">🗓️</div>Belum ada data tenggat.</div>';
    }
    html += '</div>';

    html += '<div class="card" style="padding:22px;">';
    html += '<h3 style="margin:0 0 4px;font-size:16px;font-weight:800;">Status profil Anda</h3>';
    if(!state.profile){
      html += '<p class="section-sub">Profil belum lengkap. Lengkapi untuk melihat beasiswa yang benar-benar cocok untuk Anda.</p>';
      html += '<button class="btn btn-primary btn-sm" data-nav="profil">Isi profil sekarang</button>';
    } else {
      html += '<div class="profile-summary">';
      html += '<span class="badge badge-gray">'+esc(state.profile.jenjang||"-")+'</span>';
      html += '<span class="badge badge-gray">'+esc(state.profile.jurusan||"-")+'</span>';
      html += '<span class="badge badge-gray">IPK '+esc(state.profile.ipk!==undefined?state.profile.ipk:"-")+'</span>';
      html += '<span class="badge badge-gray">'+esc(state.profile.domisili||"-")+'</span>';
      html += '</div>';
      html += '<p class="section-sub" style="margin-top:10px;">'+matchedCount+' dari '+active.length+' beasiswa aktif cocok dengan profil Anda.</p>';
      html += '<button class="btn btn-outline btn-sm" data-nav="cari">Lihat beasiswa cocok</button>';
    }
    html += '</div>';

    html += '</div>';

    html += '<div class="disclaimer" style="margin-top:20px;">Informasi pada platform ini dikurasi secara manual dari sumber resmi masing-masing penyelenggara. Selalu periksa tanggal pembaruan dan verifikasi persyaratan langsung ke penyelenggara sebelum mendaftar. Profil dan daftar simpanan Anda tersimpan secara lokal di browser perangkat ini.</div>';
    return html;
  }
  function afterRenderBeranda(){
    document.querySelectorAll('[data-nav]').forEach(function(el){
      el.addEventListener("click", function(){ navigate(el.dataset.nav); });
    });
    animateAllCounts();
  }

  /* ---------- CARI BEASISWA ---------- */
  function viewCari(){
    var f = state.filters;
    var list = activeScholarships();

    if(f.q){
      var q = f.q.toLowerCase();
      list = list.filter(function(s){
        return (s.nama||"").toLowerCase().indexOf(q) !== -1 ||
               (s.penyelenggara||"").toLowerCase().indexOf(q) !== -1 ||
               (s.deskripsi||"").toLowerCase().indexOf(q) !== -1;
      });
    }
    if(f.jenjang){
      list = list.filter(function(s){
        var jl = (s.syarat && s.syarat.jenjang) || ["Semua"];
        return jl.indexOf("Semua") !== -1 || jl.indexOf(f.jenjang) !== -1;
      });
    }
    if(f.jenis){
      list = list.filter(function(s){ return s.jenisPembiayaan === f.jenis; });
    }
    if(f.onlyMatch && state.profile){
      list = list.filter(function(s){ return matchResult(s, state.profile).ok; });
    }
    list.sort(function(a,b){
      var da = daysLeft(a.tenggat), db2 = daysLeft(b.tenggat);
      if(da===null) da = 99999; if(db2===null) db2 = 99999;
      return da - db2;
    });

    var html = '<h2 class="section-title">Cari &amp; Cocokkan Beasiswa</h2>';
    html += '<p class="section-sub">Saring berdasarkan jenjang, jenis pembiayaan, atau kata kunci — aktifkan "hanya yang cocok" untuk menyaring otomatis sesuai profil Anda.</p>';

    html += '<div class="filter-bar">';
    html += '<input type="text" id="fQ" placeholder="Cari nama beasiswa, penyelenggara, kata kunci..." value="'+escapeAttr(f.q)+'">';
    html += '<select id="fJenjang"><option value="">Semua jenjang</option>'+
      ["D3","S1","S2","S3"].map(function(j){return '<option value="'+j+'"'+(f.jenjang===j?' selected':'')+'>'+j+'</option>';}).join('')+
      '</select>';
    html += '<select id="fJenis"><option value="">Semua pembiayaan</option>'+
      ["Penuh","Parsial"].map(function(j){return '<option value="'+j+'"'+(f.jenis===j?' selected':'')+'>'+j+'</option>';}).join('')+
      '</select>';
    html += '<label class="switch-row"><span class="switch"><input type="checkbox" id="fMatch" '+(f.onlyMatch?'checked':'')+'><span class="switch-track"><span class="switch-knob"></span></span></span>Hanya yang cocok dengan profil</label>';
    html += '</div>';

    if(f.onlyMatch && !state.profile){
      html += '<div class="match-gate"><strong>Profil Anda belum lengkap.</strong><br><span style="color:var(--ink-soft);font-size:13px;">Lengkapi profil untuk melihat beasiswa yang sesuai secara otomatis.</span><br><br><button class="btn btn-primary btn-sm" data-nav="profil">Lengkapi profil</button></div>';
      return html;
    }

    html += '<div class="sch-list" id="schList">';
    if(!list.length){
      html += '<div class="empty"><div class="big">🔍</div>Tidak ada beasiswa yang cocok dengan filter ini.</div>';
    } else {
      list.forEach(function(s, idx){ html += scholarshipCard(s, idx); });
    }
    html += '</div>';
    return html;
  }

  function scholarshipCard(s, idx){
    var m = state.profile ? matchResult(s, state.profile) : null;
    var isSaved = !!state.saved[s.id];
    var html = '<div class="card kartu" style="--i:'+(idx||0)+';">';
    html += '<div class="sch-main">';
    html += '<div class="sch-tags">';
    if(s.unggulan) html += '<span class="stamp stamp-sponsor">Sponsor</span>';
    html += '<span class="badge badge-gray">'+esc(s.jenisPembiayaan||"-")+'</span>';
    if(m) html += m.ok ? '<span class="stamp">✓ Cocok</span>' : '<span class="stamp stamp-off">Belum cocok</span>';
    html += '</div>';
    html += '<h4>'+esc(s.nama)+'</h4>';
    html += '<div class="org">'+esc(s.penyelenggara||"")+'</div>';
    html += '<p class="desc">'+esc((s.deskripsi||"").slice(0,160))+((s.deskripsi||"").length>160?'…':'')+'</p>';
    html += ticketDeadline(s.tenggat) + '<span style="margin-left:8px;font-size:11.5px;color:var(--ink-faint);">Diperbarui '+fmtDate(s.tanggalPembaruan)+'</span>';
    html += '</div>';
    html += '<div class="sch-actions">';
    html += '<button class="btn btn-outline btn-sm" data-detail="'+s.id+'">Lihat detail</button>';
    if(isSaved){
      html += '<button class="btn btn-ghost btn-sm" data-unsave="'+s.id+'">✓ Tersimpan</button>';
    } else {
      html += '<button class="btn btn-primary btn-sm" data-save="'+s.id+'">Simpan</button>';
    }
    html += '</div></div>';
    return html;
  }

  function afterRenderCari(){
    var q = document.getElementById("fQ");
    if(q) q.addEventListener("input", function(){ state.filters.q = q.value; renderListOnly(); });
    var fj = document.getElementById("fJenjang");
    if(fj) fj.addEventListener("change", function(){ state.filters.jenjang = fj.value; render(); });
    var fjs = document.getElementById("fJenis");
    if(fjs) fjs.addEventListener("change", function(){ state.filters.jenis = fjs.value; render(); });
    var fm = document.getElementById("fMatch");
    if(fm) fm.addEventListener("change", function(){ state.filters.onlyMatch = fm.checked; render(); });
    wireCardActions();
  }
  function renderListOnly(){
    var main = document.getElementById("mainContent");
    var scrollY = window.scrollY;
    main.innerHTML = viewCari();
    afterRenderCari();
    var qEl = document.getElementById("fQ");
    if(qEl){ qEl.focus(); qEl.setSelectionRange(qEl.value.length, qEl.value.length); }
    window.scrollTo(0, scrollY);
  }
  function wireCardActions(){
    document.querySelectorAll('[data-save]').forEach(function(el){ el.addEventListener("click", function(){ saveScholarship(el.dataset.save); }); });
    document.querySelectorAll('[data-unsave]').forEach(function(el){ el.addEventListener("click", function(){ unsaveScholarship(el.dataset.unsave); }); });
    document.querySelectorAll('[data-detail]').forEach(function(el){ el.addEventListener("click", function(){ openDetailModal(el.dataset.detail); }); });
    document.querySelectorAll('[data-nav]').forEach(function(el){ el.addEventListener("click", function(){ navigate(el.dataset.nav); }); });
  }

  function openDetailModal(id){
    var s = findScholarship(id);
    if(!s) return;
    var m = state.profile ? matchResult(s, state.profile) : null;
    var req = s.syarat || {};
    var html = '<div class="modal-backdrop" id="backdrop">';
    html += '<div class="modal">';
    html += '<div class="modal-head"><h3>'+esc(s.nama)+'</h3><button class="modal-close" id="closeModalBtn">✕</button></div>';
    html += '<div class="modal-body">';
    html += '<div class="sch-tags" style="margin-bottom:10px;">';
    if(s.unggulan) html += '<span class="stamp stamp-sponsor">Sponsor</span>';
    html += '<span class="badge badge-gray">'+esc(s.jenisPembiayaan||"-")+'</span>';
    html += ticketDeadline(s.tenggat);
    html += '</div>';
    html += '<p style="font-weight:700;margin:0 0 2px;">'+esc(s.penyelenggara||"")+'</p>';
    html += '<p style="color:var(--ink-soft);font-size:13.5px;white-space:pre-wrap;">'+esc(s.deskripsi||"-")+'</p>';

    html += '<div class="card" style="padding:14px 16px;background:var(--paper);margin:12px 0;border-style:dashed;">';
    html += '<div style="font-weight:700;font-size:13px;margin-bottom:8px;font-family:var(--font-display);">Persyaratan utama</div>';
    html += '<div style="font-size:13px;color:var(--ink-soft);line-height:1.7;">';
    html += 'Jenjang: '+esc((req.jenjang||["Semua"]).join(", "))+'<br>';
    html += 'Jurusan: '+esc((req.jurusanList||["Semua"]).join(", "))+'<br>';
    html += 'IPK minimum: '+esc(req.ipkMin!==undefined?req.ipkMin:0)+'<br>';
    html += 'Domisili: '+esc((req.domisili||["Semua"]).join(", "));
    if(req.tambahan) html += '<br>Syarat tambahan: '+esc(req.tambahan);
    html += '</div></div>';

    if(m){
      html += m.ok
        ? '<div class="stamp" style="margin-bottom:10px;">✓ Profil Anda memenuhi kriteria ini</div>'
        : '<div style="font-size:12.5px;color:var(--stamp-red);margin-bottom:10px;">Belum cocok: '+esc(m.reasons.join("; "))+'</div>';
    }

    html += '<div style="font-size:11.5px;color:var(--ink-faint);margin-bottom:14px;">Data diperbarui '+fmtDate(s.tanggalPembaruan)+'. Selalu verifikasi ke sumber resmi sebelum mendaftar.</div>';

    html += '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
    if(s.tautanResmi) html += '<a class="btn btn-primary btn-sm" href="'+escapeAttr(s.tautanResmi)+'" target="_blank" rel="noopener">Buka sumber resmi ↗</a>';
    if(state.saved[id]){
      html += '<button class="btn btn-ghost btn-sm" data-unsave="'+id+'">✓ Tersimpan — hapus</button>';
    } else {
      html += '<button class="btn btn-outline btn-sm" data-save="'+id+'">Simpan beasiswa ini</button>';
    }
    html += '</div></div></div></div>';

    document.getElementById("modalRoot").innerHTML = html;
    document.getElementById("closeModalBtn").addEventListener("click", closeModal);
    document.getElementById("backdrop").addEventListener("click", function(e){ if(e.target.id==="backdrop") closeModal(); });
    wireCardActions();
    document.querySelectorAll('[data-save],[data-unsave]').forEach(function(el){
      el.addEventListener("click", function(){ setTimeout(closeModal, 150); });
    });
  }
  function closeModal(){ document.getElementById("modalRoot").innerHTML = ""; }

  /* ---------- TERSIMPAN ---------- */
  function viewTersimpan(){
    var html = '<h2 class="section-title">Beasiswa Tersimpan</h2>';
    html += '<p class="section-sub">Kelola kesiapan berkas dan pantau tenggat untuk setiap beasiswa incaran Anda.</p>';

    var ids = Object.keys(state.saved);
    if(!ids.length){
      html += '<div class="empty"><div class="big">📌</div>Belum ada beasiswa yang disimpan.<br><button class="btn btn-primary btn-sm" data-nav="cari" style="margin-top:12px;">Cari beasiswa</button></div>';
      return html;
    }
    ids.sort(function(a,b){
      var sa = findScholarship(a), sb = findScholarship(b);
      var da = sa ? daysLeft(sa.tenggat) : 99999, db2 = sb ? daysLeft(sb.tenggat) : 99999;
      if(da===null) da = 99999; if(db2===null) db2 = 99999;
      return da - db2;
    });
    html += '<div class="sch-list">';
    ids.forEach(function(id){
      var s = findScholarship(id);
      var sv = state.saved[id];
      if(!s){
        html += '<div class="card saved-card"><em style="color:var(--ink-faint);">Data beasiswa ini sudah tidak tersedia.</em> <button class="btn btn-ghost btn-sm" data-unsave="'+id+'">Hapus</button></div>';
        return;
      }
      html += '<div class="card saved-card">';
      html += '<div class="saved-top">';
      html += '<div><h4 style="margin:0 0 2px;font-size:15.5px;font-weight:800;">'+esc(s.nama)+'</h4>';
      html += '<div style="font-size:12.5px;color:var(--ink-soft);">'+esc(s.penyelenggara||"")+'</div></div>';
      html += ticketDeadline(s.tenggat);
      html += '</div>';

      html += '<select data-status="'+id+'" style="width:auto;padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:12.5px;font-weight:600;margin-bottom:10px;background:var(--paper-raised);">';
      ["Belum mulai","Menyiapkan berkas","Sudah mendaftar"].forEach(function(st){
        html += '<option value="'+st+'"'+(sv.statusPersiapan===st?' selected':'')+'>'+st+'</option>';
      });
      html += '</select>';

      var berkasArr = sv.berkas || [];
      if(berkasArr.length){
        var doneN = berkasArr.filter(function(b){return b.selesai;}).length;
        var pct = Math.round(doneN / berkasArr.length * 100);
        html += '<div class="progress-label">Kesiapan berkas: '+doneN+'/'+berkasArr.length+' ('+pct+'%)</div>';
        html += '<div class="progress-track"><div class="progress-fill" style="width:'+pct+'%;"></div></div>';
      }

      html += '<div class="checklist">';
      berkasArr.forEach(function(b, idx){
        html += '<label class="checklist-item '+(b.selesai?'done':'')+'"><input type="checkbox" data-toggle-berkas="'+id+'|'+idx+'" '+(b.selesai?'checked':'')+'><span>'+esc(b.nama)+'</span>';
        html += '<button class="btn-ghost" data-remove-berkas="'+id+'|'+idx+'" style="margin-left:auto;border:none;background:none;color:var(--ink-faint);font-size:12px;">✕</button></label>';
      });
      html += '</div>';
      html += '<div class="add-berkas"><input type="text" placeholder="Tambah item berkas (contoh: Surat rekomendasi)" data-newberkas="'+id+'"><button class="btn btn-outline btn-sm" data-addberkas="'+id+'">Tambah</button></div>';

      html += '<div style="margin-top:10px;display:flex;gap:8px;">';
      if(s.tautanResmi) html += '<a class="btn btn-ghost btn-sm" href="'+escapeAttr(s.tautanResmi)+'" target="_blank" rel="noopener">Sumber resmi ↗</a>';
      html += '<button class="btn btn-danger btn-sm" data-unsave="'+id+'">Hapus dari daftar</button>';
      html += '</div>';
      html += '</div>';
    });
    html += '</div>';
    return html;
  }
  function afterRenderTersimpan(){
    document.querySelectorAll('[data-nav]').forEach(function(el){ el.addEventListener("click", function(){ navigate(el.dataset.nav); }); });
    document.querySelectorAll('[data-unsave]').forEach(function(el){ el.addEventListener("click", function(){ unsaveScholarship(el.dataset.unsave); }); });
    document.querySelectorAll('[data-status]').forEach(function(el){ el.addEventListener("change", function(){ updateSavedStatus(el.dataset.status, el.value); }); });
    document.querySelectorAll('[data-toggle-berkas]').forEach(function(el){
      el.addEventListener("change", function(){ var p = el.dataset.toggleBerkas.split("|"); toggleBerkasItem(p[0], parseInt(p[1],10)); });
    });
    document.querySelectorAll('[data-remove-berkas]').forEach(function(el){
      el.addEventListener("click", function(){ var p = el.dataset.removeBerkas.split("|"); removeBerkasItem(p[0], parseInt(p[1],10)); });
    });
    document.querySelectorAll('[data-addberkas]').forEach(function(el){
      el.addEventListener("click", function(){
        var id = el.dataset.addberkas;
        var input = document.querySelector('[data-newberkas="'+id+'"]');
        if(input && input.value.trim()){ addBerkasItem(id, input.value); input.value=""; }
      });
    });
  }

  /* ---------- PROFIL ---------- */
  function viewProfil(){
    var html = '<h2 class="section-title">Profil Saya</h2>';
    html += '<p class="section-sub">Data ini dipakai untuk mencocokkan Anda secara otomatis dengan beasiswa yang tersedia. Data hanya tersimpan secara lokal di browser perangkat ini.</p>';
    var p = state.profile || {};
    html += '<div class="card" style="padding:22px;max-width:560px;">';
    html += '<div class="field"><label>Nama lengkap</label><input type="text" id="pNama" value="'+escapeAttr(p.nama||"")+'" placeholder="Nama Anda"></div>';
    html += '<div class="field-row">';
    html += '<div class="field"><label>Jenjang pendidikan</label><select id="pJenjang">'+
      ["","D3","S1","S2","S3"].map(function(j){return '<option value="'+j+'"'+(p.jenjang===j?' selected':'')+'>'+(j||"Pilih jenjang")+'</option>';}).join('')+
      '</select></div>';
    html += '<div class="field"><label>Semester</label><input type="number" id="pSemester" min="1" max="20" value="'+escapeAttr(p.semester!==undefined?p.semester:"")+'"></div>';
    html += '</div>';
    html += '<div class="field-row">';
    html += '<div class="field"><label>Jurusan / program studi</label><input type="text" id="pJurusan" value="'+escapeAttr(p.jurusan||"")+'" placeholder="contoh: Teknik Informatika"></div>';
    html += '<div class="field"><label>IPK</label><input type="number" id="pIpk" step="0.01" min="0" max="4" value="'+escapeAttr(p.ipk!==undefined?p.ipk:"")+'"></div>';
    html += '</div>';
    html += '<div class="field"><label>Domisili (provinsi)</label><input type="text" id="pDomisili" list="provList" value="'+escapeAttr(p.domisili||"")+'" placeholder="contoh: Jawa Tengah">';
    html += '<datalist id="provList">'+PROVINSI.map(function(pr){return '<option value="'+pr+'">';}).join('')+'</datalist>';
    html += '<small class="hint">Dipakai untuk beasiswa daerah/kampus yang membatasi domisili tertentu.</small></div>';
    html += '<button class="btn btn-primary" id="saveProfileBtn">Simpan profil</button>';
    html += '</div>';
    return html;
  }
  function afterRenderProfil(){
    var btn = document.getElementById("saveProfileBtn");
    if(!btn) return;
    btn.addEventListener("click", function(){
      var ipkVal = parseFloat(document.getElementById("pIpk").value);
      var semVal = parseInt(document.getElementById("pSemester").value, 10);
      saveProfile({
        nama: document.getElementById("pNama").value.trim(),
        jenjang: document.getElementById("pJenjang").value,
        jurusan: document.getElementById("pJurusan").value.trim(),
        ipk: isNaN(ipkVal) ? 0 : ipkVal,
        semester: isNaN(semVal) ? 0 : semVal,
        domisili: document.getElementById("pDomisili").value.trim()
      });
    });
  }

  /* ---------- ADMIN ---------- */
  function viewAdmin(){
    var html = '<h2 class="section-title">Panel Admin</h2>';
    html += '<p class="section-sub">Kelola data beasiswa: tambah, ubah, atau nonaktifkan. Listing tidak memengaruhi urutan maupun hasil pencocokan otomatis.</p>';

    var all = allScholarships();
    var active = all.filter(function(s){ return s.statusAktif !== false; });
    var inactive = all.filter(function(s){ return s.statusAktif === false; });
    var visits = readLS(LS_VISITS, 0);

    html += '<div class="ledger">';
    html += ledgerItem(all.length, "Total beasiswa");
    html += ledgerItem(active.length, "Aktif");
    html += ledgerItem(inactive.length, "Nonaktif");
    html += ledgerItem(visits, "Kunjungan (perangkat ini)");
    html += '</div>';

    html += '<div class="disclaimer">Angka "Kunjungan" di atas hanya hitungan lokal di browser ini, bukan statistik pengunjung situs sesungguhnya. Untuk statistik pengunjung real-time yang akurat, aktifkan <strong>Netlify Analytics</strong> di dashboard Netlify atau pasang Google Analytics / Plausible — lihat README.md.</div>';

    html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:10px;">';
    html += '<div class="tabs-sub" style="margin-bottom:0;border-bottom:none;">';
    html += '<button data-admintab="aktif" class="'+(state.adminTab==="aktif"?"active":"")+'">Aktif ('+active.length+')</button>';
    html += '<button data-admintab="nonaktif" class="'+(state.adminTab==="nonaktif"?"active":"")+'">Nonaktif ('+inactive.length+')</button>';
    html += '</div>';
    html += '<div style="display:flex;gap:8px;">';
    html += '<button class="btn btn-ghost btn-sm" id="resetDataBtn">Reset ke contoh bawaan</button>';
    html += '<button class="btn btn-primary btn-sm" id="addSchBtn">+ Tambah beasiswa</button>';
    html += '</div></div>';

    var list = state.adminTab === "aktif" ? active : inactive;
    html += '<div class="card">';
    if(!list.length){
      html += '<div class="empty">Tidak ada data.</div>';
    } else {
      list.forEach(function(s){
        html += '<div class="admin-row">';
        html += '<div class="ar-main"><h4>'+esc(s.nama)+' '+(s.unggulan?'<span class="stamp stamp-sponsor">Sponsor</span>':'')+'</h4>';
        html += '<div class="meta">'+esc(s.penyelenggara||"")+' • Tenggat '+fmtDate(s.tenggat)+' • Diperbarui '+fmtDate(s.tanggalPembaruan)+'</div></div>';
        html += '<div class="admin-actions">';
        html += '<button class="btn btn-outline btn-sm" data-edit="'+s.id+'">Ubah</button>';
        if(s.statusAktif === false){
          html += '<button class="btn btn-ghost btn-sm" data-activate="'+s.id+'">Aktifkan</button>';
        } else {
          html += '<button class="btn btn-ghost btn-sm" data-deactivate="'+s.id+'">Nonaktifkan</button>';
        }
        html += '<button class="btn btn-danger btn-sm" data-delete="'+s.id+'">Hapus</button>';
        html += '</div></div>';
      });
    }
    html += '</div>';
    return html;
  }
  function afterRenderAdmin(){
    animateAllCounts();
    document.querySelectorAll('[data-admintab]').forEach(function(el){ el.addEventListener("click", function(){ state.adminTab = el.dataset.admintab; render(); }); });
    var addBtn = document.getElementById("addSchBtn");
    if(addBtn) addBtn.addEventListener("click", function(){ openAdminForm(null); });
    var resetBtn = document.getElementById("resetDataBtn");
    if(resetBtn) resetBtn.addEventListener("click", adminResetData);
    document.querySelectorAll('[data-edit]').forEach(function(el){ el.addEventListener("click", function(){ openAdminForm(findScholarship(el.dataset.edit)); }); });
    document.querySelectorAll('[data-deactivate]').forEach(function(el){ el.addEventListener("click", function(){ adminSetActive(el.dataset.deactivate, false); }); });
    document.querySelectorAll('[data-activate]').forEach(function(el){ el.addEventListener("click", function(){ adminSetActive(el.dataset.activate, true); }); });
    document.querySelectorAll('[data-delete]').forEach(function(el){ el.addEventListener("click", function(){ adminDelete(el.dataset.delete); }); });
  }

  function openAdminForm(existing){
    var s = existing || {};
    var req = s.syarat || {};
    var jenjangList = req.jenjang || [];
    var html = '<div class="modal-backdrop" id="backdrop"><div class="modal" style="max-width:640px;">';
    html += '<div class="modal-head"><h3>'+(existing?"Ubah beasiswa":"Tambah beasiswa baru")+'</h3><button class="modal-close" id="closeModalBtn">✕</button></div>';
    html += '<div class="modal-body">';
    html += '<div class="field"><label>Nama beasiswa</label><input type="text" id="fNama" value="'+escapeAttr(s.nama||"")+'"></div>';
    html += '<div class="field-row">';
    html += '<div class="field"><label>Penyelenggara</label><input type="text" id="fPenyelenggara" value="'+escapeAttr(s.penyelenggara||"")+'"></div>';
    html += '<div class="field"><label>Jenis pembiayaan</label><select id="fJenisPembiayaan">'+
      ["Penuh","Parsial"].map(function(j){return '<option value="'+j+'"'+(s.jenisPembiayaan===j?' selected':'')+'>'+j+'</option>';}).join('')+
      '</select></div>';
    html += '</div>';
    html += '<div class="field"><label>Deskripsi</label><textarea id="fDeskripsi" rows="3">'+esc(s.deskripsi||"")+'</textarea></div>';
    html += '<div class="field-row">';
    html += '<div class="field"><label>Tenggat pendaftaran</label><input type="date" id="fTenggat" value="'+escapeAttr(s.tenggat||"")+'"></div>';
    html += '<div class="field"><label>Tautan resmi</label><input type="url" id="fTautan" value="'+escapeAttr(s.tautanResmi||"")+'" placeholder="https://..."></div>';
    html += '</div>';

    html += '<div class="field"><label>Jenjang yang memenuhi syarat</label><div class="checkrow">'+
      ["D3","S1","S2","S3","Semua"].map(function(j){
        return '<label><input type="checkbox" class="fJenjangChk" value="'+j+'" '+(jenjangList.indexOf(j)!==-1?'checked':'')+'>'+j+'</label>';
      }).join('')+'</div></div>';

    html += '<div class="field-row">';
    html += '<div class="field"><label>Jurusan (pisahkan dengan koma, atau "Semua")</label><input type="text" id="fJurusan" value="'+escapeAttr((req.jurusanList||[]).join(", "))+'" placeholder="Semua"></div>';
    html += '<div class="field"><label>IPK minimum</label><input type="number" id="fIpkMin" step="0.01" min="0" max="4" value="'+escapeAttr(req.ipkMin!==undefined?req.ipkMin:0)+'"></div>';
    html += '</div>';
    html += '<div class="field"><label>Domisili (pisahkan dengan koma, atau "Semua")</label><input type="text" id="fDomisili" value="'+escapeAttr((req.domisili||[]).join(", "))+'" placeholder="Semua"></div>';
    html += '<div class="field"><label>Syarat tambahan (teks bebas)</label><textarea id="fTambahan" rows="2">'+esc(req.tambahan||"")+'</textarea></div>';

    html += '<div class="checkrow" style="margin-bottom:16px;">';
    html += '<label><input type="checkbox" id="fUnggulan" '+(s.unggulan?'checked':'')+'> Listing unggulan (Sponsor)</label>';
    html += '<label><input type="checkbox" id="fAktif" '+(s.statusAktif!==false?'checked':'')+'> Status aktif</label>';
    html += '</div>';

    html += '<div style="display:flex;gap:8px;"><button class="btn btn-primary" id="submitSchBtn">'+(existing?"Simpan perubahan":"Tambahkan beasiswa")+'</button><button class="btn btn-ghost" id="cancelSchBtn">Batal</button></div>';
    html += '</div></div></div>';

    document.getElementById("modalRoot").innerHTML = html;
    document.getElementById("closeModalBtn").addEventListener("click", closeModal);
    document.getElementById("cancelSchBtn").addEventListener("click", closeModal);
    document.getElementById("backdrop").addEventListener("click", function(e){ if(e.target.id==="backdrop") closeModal(); });
    document.getElementById("submitSchBtn").addEventListener("click", function(){
      var jenjangChecked = Array.prototype.slice.call(document.querySelectorAll(".fJenjangChk:checked")).map(function(c){return c.value;});
      var data = {
        nama: document.getElementById("fNama").value.trim(),
        penyelenggara: document.getElementById("fPenyelenggara").value.trim(),
        jenisPembiayaan: document.getElementById("fJenisPembiayaan").value,
        deskripsi: document.getElementById("fDeskripsi").value.trim(),
        tenggat: document.getElementById("fTenggat").value,
        tautanResmi: document.getElementById("fTautan").value.trim(),
        unggulan: document.getElementById("fUnggulan").checked,
        statusAktif: document.getElementById("fAktif").checked,
        syarat: {
          jenjang: jenjangChecked.length ? jenjangChecked : ["Semua"],
          jurusanList: listify(document.getElementById("fJurusan").value) || ["Semua"],
          ipkMin: parseFloat(document.getElementById("fIpkMin").value) || 0,
          domisili: listify(document.getElementById("fDomisili").value) || ["Semua"],
          tambahan: document.getElementById("fTambahan").value.trim()
        }
      };
      if(!data.nama){ toast("Nama beasiswa wajib diisi."); return; }
      if(!data.syarat.jurusanList.length) data.syarat.jurusanList = ["Semua"];
      if(!data.syarat.domisili.length) data.syarat.domisili = ["Semua"];
      adminUpsertScholarship(data, existing ? existing.id : null);
    });
  }

  /* ===================== bootstrap ===================== */
  document.addEventListener("DOMContentLoaded", function(){
    document.getElementById("mainNav").addEventListener("click", function(e){
      var btn = e.target.closest("button[data-view]");
      if(btn) navigate(btn.dataset.view);
    });
    document.getElementById("hamburgerBtn").addEventListener("click", function(){
      document.getElementById("mainNav").classList.toggle("open");
    });
    if(state.isAdmin) document.getElementById("navAdmin").classList.remove("hidden");
    updateStatusPill();
    trackLocalVisit();
    render();
  });
})();
