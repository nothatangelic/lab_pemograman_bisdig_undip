/* Data awal (seed) beasiswa.
   Ini HANYA dipakai sebagai nilai default saat localStorage situs masih kosong.
   Admin bisa menambah/mengubah/menonaktifkan lewat Panel Admin di situs,
   atau Anda bisa mengedit array ini langsung sebelum deploy. */
var DEFAULT_SCHOLARSHIPS = [
  {
    id: "d001",
    nama: "Beasiswa Unggulan Kemdikbudristek",
    penyelenggara: "Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi",
    deskripsi: "Beasiswa penuh bagi mahasiswa berprestasi akademik dan non-akademik, mencakup biaya pendidikan, tunjangan buku, dan biaya hidup bulanan selama masa studi.",
    jenisPembiayaan: "Penuh",
    tenggat: "2026-12-20",
    tautanResmi: "https://beasiswaunggulan.kemdikbud.go.id/",
    tanggalPembaruan: "2026-11-20",
    statusAktif: true,
    unggulan: true,
    syarat: { jenjang: ["S1","S2"], jurusanList: ["Semua"], ipkMin: 3.25, domisili: ["Semua"], tambahan: "Melampirkan sertifikat prestasi akademik/non-akademik tingkat nasional atau internasional." }
  },
  {
    id: "d002",
    nama: "KIP Kuliah",
    penyelenggara: "Puslapdik Kemdikbudristek",
    deskripsi: "Bantuan biaya pendidikan dan biaya hidup bagi calon mahasiswa dari keluarga tidak mampu secara ekonomi namun memiliki potensi akademik baik.",
    jenisPembiayaan: "Penuh",
    tenggat: "2027-03-01",
    tautanResmi: "https://kip-kuliah.kemdikbud.go.id/",
    tanggalPembaruan: "2026-11-18",
    statusAktif: true,
    unggulan: false,
    syarat: { jenjang: ["D3","S1"], jurusanList: ["Semua"], ipkMin: 0, domisili: ["Semua"], tambahan: "Terdaftar dalam Data Terpadu Kesejahteraan Sosial (DTKS) atau bukti ketidakmampuan ekonomi lain." }
  },
  {
    id: "d003",
    nama: "Beasiswa Bank Indonesia",
    penyelenggara: "Bank Indonesia",
    deskripsi: "Beasiswa parsial tahunan bagi mahasiswa S1 semester 5-7 disertai program pengembangan diri dan jaringan Generasi Baru Indonesia (GenBI).",
    jenisPembiayaan: "Parsial",
    tenggat: "2026-12-05",
    tautanResmi: "https://www.bi.go.id/id/tentang-bi/beasiswa/default.aspx",
    tanggalPembaruan: "2026-11-15",
    statusAktif: true,
    unggulan: true,
    syarat: { jenjang: ["S1"], jurusanList: ["Semua"], ipkMin: 3, domisili: ["Semua"], tambahan: "Minimal semester 5, aktif berorganisasi, tidak sedang menerima beasiswa lain." }
  },
  {
    id: "d004",
    nama: "Beasiswa Djarum Plus",
    penyelenggara: "Djarum Foundation",
    deskripsi: "Beasiswa parsial bagi mahasiswa S1 semester 4 dengan pembinaan soft skill berupa pelatihan kepemimpinan dan karakter.",
    jenisPembiayaan: "Parsial",
    tenggat: "2026-12-31",
    tautanResmi: "https://djarumbeasiswaplus.org/",
    tanggalPembaruan: "2026-11-10",
    statusAktif: true,
    unggulan: false,
    syarat: { jenjang: ["S1"], jurusanList: ["Semua"], ipkMin: 3.2, domisili: ["Semua"], tambahan: "Lolos tahap wawancara dan tes kepribadian." }
  },
  {
    id: "d005",
    nama: "Beasiswa Pemerintah Daerah Jawa Tengah",
    penyelenggara: "Pemerintah Provinsi Jawa Tengah",
    deskripsi: "Bantuan biaya pendidikan bagi mahasiswa dengan KTP Jawa Tengah yang berkuliah di perguruan tinggi negeri maupun swasta terakreditasi.",
    jenisPembiayaan: "Parsial",
    tenggat: "2026-12-15",
    tautanResmi: "https://jatengprov.go.id/",
    tanggalPembaruan: "2026-11-22",
    statusAktif: true,
    unggulan: false,
    syarat: { jenjang: ["D3","S1"], jurusanList: ["Semua"], ipkMin: 2.75, domisili: ["Jawa Tengah"], tambahan: "Melampirkan KTP/KK Jawa Tengah dan surat keterangan tidak mampu dari kelurahan." }
  },
  {
    id: "d006",
    nama: "Beasiswa Fakultas Teknik Berprestasi",
    penyelenggara: "Universitas (contoh kurasi kampus)",
    deskripsi: "Beasiswa internal kampus untuk mahasiswa Fakultas Teknik dengan prestasi akademik tinggi, berupa potongan UKT satu semester.",
    jenisPembiayaan: "Parsial",
    tenggat: "2026-12-10",
    tautanResmi: "",
    tanggalPembaruan: "2026-11-12",
    statusAktif: true,
    unggulan: false,
    syarat: { jenjang: ["S1"], jurusanList: ["Teknik Informatika","Teknik Elektro","Teknik Industri","Sistem Informasi"], ipkMin: 3.5, domisili: ["Semua"], tambahan: "Diprioritaskan bagi mahasiswa semester 3 ke atas tanpa nilai D/E." }
  },
  {
    id: "d007",
    nama: "Beasiswa Yayasan Baitul Maal (Yatim & Dhuafa)",
    penyelenggara: "Yayasan Baitul Maal",
    deskripsi: "Beasiswa penuh bagi mahasiswa yatim/dhuafa berprestasi, mencakup UKT penuh dan uang saku bulanan hingga lulus.",
    jenisPembiayaan: "Penuh",
    tenggat: "2026-12-28",
    tautanResmi: "",
    tanggalPembaruan: "2026-11-05",
    statusAktif: true,
    unggulan: false,
    syarat: { jenjang: ["S1"], jurusanList: ["Semua"], ipkMin: 3, domisili: ["Semua"], tambahan: "Melampirkan surat keterangan yatim/dhuafa dan rekomendasi tokoh masyarakat." }
  },
  {
    id: "d008",
    nama: "Beasiswa Riset Magister LPDP Afirmasi Daerah 3T",
    penyelenggara: "Lembaga Pengelola Dana Pendidikan (LPDP)",
    deskripsi: "Beasiswa penuh jenjang magister bagi pendaftar dari daerah tertinggal, terdepan, dan terluar (3T), termasuk biaya riset dan publikasi.",
    jenisPembiayaan: "Penuh",
    tenggat: "2027-01-31",
    tautanResmi: "https://lpdp.kemenkeu.go.id/",
    tanggalPembaruan: "2026-11-19",
    statusAktif: true,
    unggulan: true,
    syarat: { jenjang: ["S2"], jurusanList: ["Semua"], ipkMin: 3, domisili: ["Papua","Maluku","Nusa Tenggara Timur"], tambahan: "Membuat proposal riset dan lolos seleksi substansi." }
  }
];
