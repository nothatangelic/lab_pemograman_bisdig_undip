# BeasiswaMatch

Platform informasi & pencocokan beasiswa — proyek akhir mata kuliah laboratorium pemrograman.

Website ini **100% statis** (HTML, CSS, JavaScript biasa — tanpa framework, tanpa proses build, tanpa server backend), sehingga bisa langsung dijalankan di browser atau di-deploy ke Netlify dalam hitungan menit.

## Fitur

- **Beranda** — ringkasan statistik beasiswa aktif, tenggat terdekat, dan status kecocokan profil.
- **Cari & Cocokkan Beasiswa** — pencarian kata kunci, filter jenjang/jenis pembiayaan, dan pencocokan otomatis berbasis aturan (jenjang, jurusan, IPK minimum, domisili) — bukan AI, sesuai rancangan di makalah (logika berbasis kueri yang mudah diuji dan dijelaskan).
- **Profil Saya** — data jenjang, jurusan, IPK, semester, domisili.
- **Tersimpan** — daftar beasiswa incaran, status persiapan, checklist berkas dengan progress bar, dan pengingat tenggat.
- **Panel Admin** — tambah / ubah / nonaktifkan / hapus data beasiswa, dilindungi PIN sederhana.

## Cara menjalankan di komputer sendiri

Tidak perlu instalasi apa pun. Cukup buka `index.html` langsung di browser (double-click), atau jalankan server lokal sederhana bila ingin:

```bash
# opsional, hanya jika ingin menjalankan lewat local server
npx serve .
# atau
python3 -m http.server 8080
```

## Cara deploy ke Netlify

### Opsi A — Drag & drop (paling cepat, tanpa akun GitHub)
1. Buka **https://app.netlify.com/drop**
2. Login/daftar akun Netlify (gratis).
3. Seret seluruh folder proyek ini (yang berisi `index.html`, `css/`, `js/`, `netlify.toml`) ke halaman tersebut.
4. Tunggu beberapa detik — situs langsung online dengan URL `https://nama-acak.netlify.app`.
5. Di dashboard situs, buka **Site configuration → Domain management** untuk mengganti ke subdomain yang lebih sesuai, misalnya `beasiswamatch.netlify.app`.

### Opsi B — Hubungkan ke GitHub (direkomendasikan untuk tugas akhir, mendukung update otomatis)
1. Buat repository baru di GitHub, lalu unggah seluruh isi folder ini:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: BeasiswaMatch"
   git branch -M main
   git remote add origin https://github.com/USERNAME/beasiswa-match.git
   git push -u origin main
   ```
2. Di Netlify, klik **Add new site → Import an existing project → GitHub**, pilih repository tersebut.
3. Build settings:
   - **Build command**: kosongkan
   - **Publish directory**: `.`
4. Klik **Deploy site**. Setiap kali Anda `git push`, Netlify otomatis build ulang dan publish versi terbaru (continuous deployment) — cocok untuk demo progres ke dosen.

### Mengganti PIN admin sebelum deploy
Buka `js/app.js`, baris paling atas:
```js
var ADMIN_PIN = "beasiswa2026";
```
Ganti dengan PIN pilihan Anda sebelum deploy. PIN ini hanya pengaman ringan untuk demo akademik (dicek di sisi browser), **bukan** untuk data sensitif sungguhan.

## Melihat statistik pengunjung (real-time)

Website statis seperti ini tidak otomatis mencatat pengunjung — perlu salah satu dari opsi berikut:

| Opsi | Biaya | Cara pasang |
|---|---|---|
| **Netlify Analytics** (direkomendasikan, paling mudah) | Berbayar (add-on per situs) | Di dashboard Netlify: buka situs Anda → tab **Analytics** → aktifkan. Data diambil langsung dari server Netlify, tidak perlu menambah kode apa pun di situs. |
| **Google Analytics** | Gratis | Daftar di analytics.google.com, ambil kode `gtag.js`, tempel sebelum `</head>` di `index.html`. |
| **Plausible / GoatCounter** | Gratis (GoatCounter) / berbayar (Plausible) | Daftar akun, dapatkan potongan `<script>` ringan (ramah privasi, tanpa cookie), tempel sebelum `</head>` di `index.html`. |
| Statistik traffic dasar bawaan Netlify | Gratis | Tab **Site overview** di dashboard Netlify menampilkan jumlah request & bandwidth (bukan pengunjung unik, tapi gratis dan tanpa setup). |

Tempat menempel kode analitik sudah ditandai dengan komentar `<!-- STATISTIK PENGUNJUNG -->` di `index.html`.

Panel **Admin** di situs ini juga menampilkan angka "Kunjungan (perangkat ini)" — ini hanya hitungan lokal di browser masing-masing orang (untuk gambaran kasar saat demo offline), **bukan** pengganti statistik pengunjung situs yang sesungguhnya.

## Catatan penting: batasan arsitektur (harap jujur disampaikan ke dosen)

Agar bisa di-deploy sebagai situs statis gratis di Netlify tanpa server/database, **data profil, daftar simpanan, dan data beasiswa (hasil tambahan admin) disimpan di `localStorage` browser** — artinya:

- Data **tidak dibagikan antar pengguna atau antar perangkat**. Jika Anda mengisi profil di laptop, lalu membuka situs di HP, profil tidak akan muncul di sana.
- Jika pengguna membersihkan cache/localStorage browser, data tersebut hilang.
- Ini sesuai dengan gagasan MVP di makalah (fitur inti: autentikasi, CRUD, pencarian & pencocokan berbasis aturan) tetapi **belum mengimplementasikan basis data relasional bersama (MySQL/PostgreSQL)** seperti yang dirancang pada bagian "Rancangan Fitur dan Struktur Data".

**Rencana pengembangan lanjutan** (sesuai rekomendasi pada bagian kesimpulan makalah) agar data benar-benar tersimpan di server dan dibagikan antar pengguna:
1. Tambahkan backend gratis seperti **Supabase** (PostgreSQL + Auth siap pakai, ada tingkat gratis) atau **Firebase** (Firestore + Auth).
2. Ganti fungsi di `js/app.js` yang membaca/menulis `localStorage` dengan pemanggilan API Supabase/Firebase (butuh API key milik Anda sendiri).
3. Struktur tabel `users`, `scholarships`, `requirements`, `saved_scholarships` pada makalah bisa langsung dipetakan ke tabel Supabase/Firestore collection.

Menyampaikan batasan ini secara eksplisit di laporan/presentasi justru memperkuat nilai akademik (konsisten dengan gaya "kelemahan diakui secara jujur" pada kesimpulan makalah Anda).

## Struktur proyek

```
beasiswa-netlify/
├── index.html          # markup halaman (satu halaman, navigasi via JavaScript)
├── netlify.toml         # konfigurasi deploy Netlify
├── css/
│   └── style.css        # seluruh desain (tema "Arsip & Stempel Resmi")
├── js/
│   ├── data.js          # data contoh (seed) 8 beasiswa
│   └── app.js            # logika aplikasi: state, pencocokan, render, localStorage
└── README.md
```
